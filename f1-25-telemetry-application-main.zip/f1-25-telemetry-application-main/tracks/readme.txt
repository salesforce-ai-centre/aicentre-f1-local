These files in this directory are used for creating the trackmap. These files are trackfiles version v2

The files are named
<TRACK>_boundaries.track (track boundaries)
<TRACK>_innerlimit.track (track inner boundary)
<TRACK>_outerlimit.track (track outer boundary)
<TRACK>_racingline.track ("optimal" racingline, which AI uses)

Exceptions:
For Japan, which is only track in format of 8,
there are following files
Japan_outerlimit_fixed.track (needed for the track outline)
Japan_innerlimit1.track (innerlimit for the "first" loop)
Japan_innerlimit2.track (innerlimit for the "second" loop)